#ifndef MEM_SWAPS_HPP
#define MEM_SWAPS_HPP

#include <vector>
#include <algorithm>

void swapRows(std::vector<double>& matrix, int nRows, int nCols, int i, int j) {
    for (int col = 0; col < nCols; ++col) {
        int idx1 = i + col * nRows;
        int idx2 = j + col * nRows;
        std::swap(matrix[idx1], matrix[idx2]);
    }
}

void swapCols(std::vector<double>& matrix, int nRows, int nCols, int i, int j) {
    for (int row = 0; row < nRows; ++row) {
        int idx1 = row + i * nRows;
        int idx2 = row + j * nRows;
        std::swap(matrix[idx1], matrix[idx2]);
    }
}

#endif