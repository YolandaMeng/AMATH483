#include <iostream>
#include <vector>
#include <chrono>
#include <fstream>
#include <cstdlib>
#include "mem_swaps.hpp"

std::pair<int, int> getRandomIndices(int n) {
    int i = std::rand() % n;
    int j = std::rand() % (n - 1);
    if (j >= i) j++;
    return std::make_pair(i, j);
}

void fill_matrix(std::vector<double>& mat, int nRows, int nCols) {
    for (int i = 0; i < nRows * nCols; ++i)
        mat[i] = static_cast<double>(i);
}

int main() {
    std::ofstream out("mem_swap_times.csv");
    out << "n,row_time,col_time\n";

    std::srand(42);
    const int ntrial = 5;

    for (int n = 16; n <= 4096; n *= 2) {
        std::vector<double> mat(n * n);
        fill_matrix(mat, n, n);

        double total_row_time = 0.0;
        for (int t = 0; t < ntrial; ++t) {
            std::pair<int, int> ij = getRandomIndices(n);
            int i = ij.first;
            int j = ij.second;
            auto start = std::chrono::high_resolution_clock::now();
            swapRows(mat, n, n, i, j);
            auto end = std::chrono::high_resolution_clock::now();
            total_row_time += std::chrono::duration<double>(end - start).count();
        }
        double avg_row_time = total_row_time / ntrial;

        double total_col_time = 0.0;
        for (int t = 0; t < ntrial; ++t) {
            std::pair<int, int> ij = getRandomIndices(n);
            int i = ij.first;
            int j = ij.second;
            auto start = std::chrono::high_resolution_clock::now();
            swapCols(mat, n, n, i, j);
            auto end = std::chrono::high_resolution_clock::now();
            total_col_time += std::chrono::duration<double>(end - start).count();
        }
        double avg_col_time = total_col_time / ntrial;

        out << n << "," << avg_row_time << "," << avg_col_time << "\n";
        std::cout << "n=" << n << " row: " << avg_row_time << "s, col: " << avg_col_time << "s\n";
    }

    out.close();
    return 0;
}