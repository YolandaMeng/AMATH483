#include "strassen-1.cpp"
#include <chrono>
#include <fstream>
#include <random>

using namespace std;

template <typename T>
void fillMatrix(vector<vector<T>>& mat, int n) {
    mt19937 rng(42);
    uniform_real_distribution<T> dist(0.0, 1.0);
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j)
            mat[i][j] = dist(rng);
}

int main() {
    ofstream out("strassen_perf.csv");
    out << "n,GFLOPS\n";

    const int ntrial = 3;

    for (int n = 2; n <= 512; n *= 2) {
        vector<vector<double>> A(n, vector<double>(n));
        vector<vector<double>> B(n, vector<double>(n));

        fillMatrix(A, n);
        fillMatrix(B, n);

        double total_time = 0.0;
        for (int t = 0; t < ntrial; ++t) {
            auto start = chrono::high_resolution_clock::now();
            auto C = strassenMultiply(A, B);
            auto end = chrono::high_resolution_clock::now();
            chrono::duration<double> elapsed = end - start;
            total_time += elapsed.count();
        }

        double avg_time = total_time / ntrial;
        double flops = 2.0 * n * n * n / avg_time / 1e9;  // GFLOP/s
        out << n << "," << flops << "\n";
        cout << "n = " << n << ": " << flops << " GFLOP/s\n";
    }

    out.close();
    return 0;
}