#include <iostream>
#include <vector>
#include <fstream>
#include <chrono>
#include <cblas.h>

// L1: daxpy benchmark
double benchmark_daxpy(int n, int ntrial) {
    std::vector<double> X(n, 1.0), Y(n, 2.0);
    double alpha = 2.5;
    auto start = std::chrono::high_resolution_clock::now();

    for (int i = 0; i < ntrial; ++i)
        cblas_daxpy(n, alpha, X.data(), 1, Y.data(), 1);

    auto end = std::chrono::high_resolution_clock::now();
    double seconds = std::chrono::duration<double>(end - start).count();
    double flops = 2.0 * n * ntrial;
    return (flops / 1e6) / seconds;  // MFLOPs
}

// L2: dgemv benchmark
double benchmark_dgemv(int n, int ntrial) {
    std::vector<double> A(n * n, 1.0), X(n, 1.0), Y(n, 0.0);
    double alpha = 1.0, beta = 0.0;
    auto start = std::chrono::high_resolution_clock::now();

    for (int i = 0; i < ntrial; ++i)
        cblas_dgemv(CblasColMajor, CblasNoTrans, n, n, alpha, A.data(), n, X.data(), 1, beta, Y.data(), 1);

    auto end = std::chrono::high_resolution_clock::now();
    double seconds = std::chrono::duration<double>(end - start).count();
    double flops = 2.0 * n * n * ntrial;
    return (flops / 1e6) / seconds;  // MFLOPs
}

// L3: dgemm benchmark
double benchmark_dgemm(int n, int ntrial) {
    std::vector<double> A(n * n, 1.0), B(n * n, 1.0), C(n * n, 0.0);
    double alpha = 1.0, beta = 0.0;
    auto start = std::chrono::high_resolution_clock::now();

    for (int i = 0; i < ntrial; ++i)
        cblas_dgemm(CblasColMajor, CblasNoTrans, CblasNoTrans, n, n, n, alpha,
                    A.data(), n, B.data(), n, beta, C.data(), n);

    auto end = std::chrono::high_resolution_clock::now();
    double seconds = std::chrono::duration<double>(end - start).count();
    double flops = 2.0 * n * n * n * ntrial;
    return (flops / 1e6) / seconds;  // MFLOPs
}

int main() {
    const int ntrial = 5;
    std::ofstream out("blas_mflops.csv");
    out << "n,daxpy,dgemv,dgemm\n";

    for (int n = 2; n <= 4096; n *= 2) {
        double mflops_daxpy = benchmark_daxpy(n, ntrial);
        double mflops_dgemv = benchmark_dgemv(n, ntrial);
        double mflops_dgemm = benchmark_dgemm(n, ntrial);
        out << n << "," << mflops_daxpy << "," << mflops_dgemv << "," << mflops_dgemm << "\n";
        std::cout << "n=" << n << " done.\n";
    }

    out.close();
    return 0;
}
