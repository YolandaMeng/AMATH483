#include <iostream>
#include <complex>
#include <vector>
#include <cstdlib>
#include <cmath>
#include <limits>
#include <fstream>
#include <cblas.h>
#include <lapacke.h>

using cdouble = std::complex<double>;

double norm2(const cdouble* vec, int size) {
    double s = 0;
    for (int i = 0; i < size; ++i)
        s += std::norm(vec[i]);
    return std::sqrt(s);
}

double max_row_sum(const cdouble* mat, int dim) {
    double max_val = 0;
    for (int i = 0; i < dim; ++i) {
        double temp = 0;
        for (int j = 0; j < dim; ++j)
            temp += std::abs(mat[i + j * dim]);
        if (temp > max_val) max_val = temp;
    }
    return max_val;
}

int main() {
    std::ofstream file("lapack_results.csv");
    file << "n,log10_residual,log10_error\n";

    for (int dim = 16; dim <= 8192; dim *= 2) {
        std::vector<cdouble> M(dim * dim), rhs(dim), sol(dim);
        std::vector<lapack_int> pivots(dim);

        srand(0);
        for (int j = 0; j < dim; ++j)
            for (int i = 0; i < dim; ++i) {
                M[i + j * dim] = cdouble(
                    0.5 - rand() / (double)RAND_MAX,
                    0.5 - rand() / (double)RAND_MAX
                );
                if (i == j) M[i + j * dim] *= dim;
            }

        srand(1);
        for (int i = 0; i < dim; ++i)
            rhs[i] = cdouble(
                0.5 - rand() / (double)RAND_MAX,
                0.5 - rand() / (double)RAND_MAX
            );

        sol = rhs;

        LAPACKE_zgesv(
            LAPACK_COL_MAJOR, dim, 1,
            reinterpret_cast<lapack_complex_double*>(M.data()), dim,
            pivots.data(),
            reinterpret_cast<lapack_complex_double*>(sol.data()), dim
        );

        std::vector<cdouble> prod(dim);
        cdouble a(1.0, 0.0), b(0.0, 0.0);
        cblas_zgemv(
            CblasColMajor, CblasNoTrans, dim, dim,
            reinterpret_cast<const void*>(&a),
            reinterpret_cast<const void*>(M.data()), dim,
            reinterpret_cast<const void*>(sol.data()), 1,
            reinterpret_cast<const void*>(&b),
            reinterpret_cast<void*>(prod.data()), 1
        );

        for (int i = 0; i < dim; ++i)
            prod[i] -= rhs[i];

        double r = norm2(prod.data(), dim);
        double anorm = max_row_sum(M.data(), dim);
        double znorm = norm2(sol.data(), dim);
        double err = r / (anorm * znorm * std::numeric_limits<double>::epsilon());

        file << dim << "," << std::log10(r) << "," << std::log10(err) << "\n";
        std::cout << "Completed n = " << dim << "\n";
    }

    file.close();
    return 0;
}
