#include <iostream>
#include <vector>
#include <chrono>
#include <cblas.h>
#include <fstream>

int main() {
    std::ofstream out("openblas.csv");
    out << "n,mflops\n";

    for (int n = 2; n <= 2048; n *= 2) {
        std::vector<double> A(n * n, 1.0), B(n * n, 1.0), C(n * n, 0.0);
        int ntrial = 3;

        double total_time = 0.0;
        for (int trial = 0; trial < ntrial; ++trial) {
            auto start = std::chrono::high_resolution_clock::now();

            cblas_dgemm(CblasColMajor, CblasNoTrans, CblasNoTrans,
                        n, n, n, 1.0, A.data(), n, B.data(), n, 0.0, C.data(), n);

            auto end = std::chrono::high_resolution_clock::now();
            double seconds = std::chrono::duration<double>(end - start).count();
            total_time += seconds;
        }

        double avg_time = total_time / ntrial;
        double flops = 2.0 * n * n * n / avg_time;
        double mflops = flops / 1e6;

        out << n << "," << mflops << "\n";
        std::cout << "n = " << n << ", MFLOPS = " << mflops << std::endl;
    }

    out.close();
    return 0;
}
