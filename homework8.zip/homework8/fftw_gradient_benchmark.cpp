#include <fftw3.h>
#include <cmath>
#include <vector>
#include <chrono>
#include <fstream>
#include <iostream>

int main() {
    int ntrial = 3;
    std::ofstream out("fftw_results.csv");
    out << "n,flops\n";

    for (int n = 16; n <= 256; n *= 2) {
        int N = n * n * n;
        double avg_time = 0.0;

        for (int t = 0; t < ntrial; ++t) {
            std::vector<fftw_complex> in(N), out_k(N), grad_k(N), grad_r(N);
            fftw_plan fwd = fftw_plan_dft_3d(n, n, n, in.data(), out_k.data(), FFTW_FORWARD, FFTW_ESTIMATE);
            fftw_plan bwd = fftw_plan_dft_3d(n, n, n, grad_k.data(), grad_r.data(), FFTW_BACKWARD, FFTW_ESTIMATE);

            // Initialize input: simple plane wave
            for (int i = 0; i < N; ++i) {
                in[i][0] = cos(2 * M_PI * i / n); // real
                in[i][1] = sin(2 * M_PI * i / n); // imag
            }

            auto start = std::chrono::high_resolution_clock::now();

            // Forward FFT
            fftw_execute(fwd);

            // Gradient in x (as example)
            for (int z = 0; z < n; ++z)
                for (int y = 0; y < n; ++y)
                    for (int x = 0; x < n; ++x) {
                        int idx = z * n * n + y * n + x;
                        int kx = (x <= n / 2) ? x : x - n;
                        double k = 2 * M_PI * kx / n;
                        grad_k[idx][0] = -out_k[idx][1] * k;
                        grad_k[idx][1] =  out_k[idx][0] * k;
                    }

            // Backward FFT
            fftw_execute(bwd);

            auto end = std::chrono::high_resolution_clock::now();
            std::chrono::duration<double> elapsed = end - start;
            avg_time += elapsed.count();

            fftw_destroy_plan(fwd);
            fftw_destroy_plan(bwd);
        }

        avg_time /= ntrial;
        double flop = (10.0 * N * std::log2(N) + 3 * N) / avg_time;
        out << n << "," << flop << "\n";
        std::cout << "FFTW n=" << n << " GFLOP/s=" << flop/1e9 << std::endl;
    }
    out.close();
}