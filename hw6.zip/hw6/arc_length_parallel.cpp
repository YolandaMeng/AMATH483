#include <iostream>
#include <vector>
#include <thread>
#include <cmath>
#include <mutex>
#include <chrono>
#include <fstream>

std::mutex mtx;

double f_prime(double x) {
    return 1.0 / x - x / 4.0;
}

double integrand(double x) {
    double fp = f_prime(x);
    return std::sqrt(1 + fp * fp);
}

void partial_integral(double a, double b, int start, int end, int n, double& result) {
    double h = (b - a) / n;
    double local_sum = 0.0;
    for (int i = start; i < end; ++i) {
        double x = a + i * h;
        local_sum += integrand(x);
    }
    local_sum *= h;

    std::lock_guard<std::mutex> lock(mtx);
    result += local_sum;
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "Usage: ./arc_length_parallel <n> <threads>\n";
        return 1;
    }

    int n = std::stoi(argv[1]);
    int num_threads = std::stoi(argv[2]);

    double a = 1.0, b = 6.0;
    double result = 0.0;

    std::vector<std::thread> threads;
    int chunk_size = n / num_threads;

    auto start_time = std::chrono::high_resolution_clock::now();

    for (int i = 0; i < num_threads; ++i) {
        int start_idx = i * chunk_size;
        int end_idx = (i == num_threads - 1) ? n : (i + 1) * chunk_size;
        threads.emplace_back(partial_integral, a, b, start_idx, end_idx, n, std::ref(result));
    }

    for (auto& t : threads) t.join();

    auto end_time = std::chrono::high_resolution_clock::now();
    double time_sec = std::chrono::duration<double>(end_time - start_time).count();

    std::cout << n << "," << num_threads << "," << result << "," << time_sec << "\n";

    // Append results to CSV file
    std::ofstream fout("arc_length_scaling.csv", std::ios::app);
    fout << n << "," << num_threads << "," << result << "," << time_sec << "\n";
    fout.close();

    return 0;
}
