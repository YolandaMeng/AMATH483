// multiple rider case attempt
/*
Passenger List: elevator maintains list of passengers (pairs of person_id and destination floor)
Batch Processing: elevator picks up as many passengers as possible from the queue if they are on the same floor, respecting the maximum occupancy
Route Management: elevator manages passengers' routes, moving to each passenger's destination floor and logging the necessary information
Complete Logging: detailed logs for each step including entering and exiting the elevator are added to provide comprehensive traceability
also
Occupancy Declaration: occupancy variable initialized to 0 at the start of the elevator function
Occupancy Management: increment occupancy each time a passenger enters the elevator and decrement each time a passenger exits.
*/

#ifndef ELEVATOR_HPP
#define ELEVATOR_HPP

#include <iostream>
#include <thread>
#include <mutex>
#include <queue>
#include <chrono>
#include <random>
#include <atomic>
#include <vector>
#include <condition_variable>
#include <tuple>

using namespace std;

const int NUM_FLOORS = 50;
const int NUM_ELEVATORS = 6;
const int MAX_OCCUPANCY = 5;
const int MAX_WAIT_TIME = 5000; // milliseconds

mutex cout_mtx;
mutex queue_mtx;
condition_variable cv;
queue<tuple<int, int, int>> global_queue; // person_id, start_floor, dest_floor
vector<int> elevator_positions(NUM_ELEVATORS, 0);
atomic<int> num_people_serviced(0);
vector<int> global_passengers_serviced(NUM_ELEVATORS, 0);
int npeople;

void person(int id) {
    int curr_floor = rand() % NUM_FLOORS;
    int dest_floor = rand() % NUM_FLOORS;
    while (dest_floor == curr_floor) {
        dest_floor = rand() % NUM_FLOORS;
    }

    {
        lock_guard<mutex> lock(cout_mtx);
        cout << "Person " << id << " wants to go from floor " << curr_floor << " to floor " << dest_floor << endl;
    }

    {
        lock_guard<mutex> lock(queue_mtx);
        global_queue.push(make_tuple(id, curr_floor, dest_floor));
    }
    cv.notify_all();
}

void elevator(int id) {
    int occupancy = 0;
    vector<pair<int, int>> passengers; // (person_id, dest_floor)

    while (num_people_serviced < npeople) {
        unique_lock<mutex> lock(queue_mtx);
        cv.wait(lock, [] { return !global_queue.empty() || num_people_serviced >= npeople; });

        if (num_people_serviced >= npeople) break;

        // Try to pick up as many passengers as possible (batch from same floor)
        while (!global_queue.empty() && occupancy < MAX_OCCUPANCY) {
            auto [pid, start, dest] = global_queue.front();
            global_queue.pop();

            if (start != elevator_positions[id]) {
                lock.unlock();
                {
                    lock_guard<mutex> cout_lock(cout_mtx);
                    cout << "Elevator " << id << " moving to floor " << start << " to pick up Person " << pid << endl;
                }
                this_thread::sleep_for(chrono::milliseconds(100));
                elevator_positions[id] = start;
                lock.lock();
            }

            passengers.emplace_back(pid, dest);
            ++occupancy;
            ++global_passengers_serviced[id];

            {
                lock_guard<mutex> cout_lock(cout_mtx);
                cout << "Person " << pid << " entered Elevator " << id << " at floor " << start << " heading to floor " << dest << endl;
            }

            ++num_people_serviced;
        }

        lock.unlock();

        for (auto [pid, dest] : passengers) {
            if (elevator_positions[id] != dest) {
                {
                    lock_guard<mutex> cout_lock(cout_mtx);
                    cout << "Elevator " << id << " moving to floor " << dest << " for Person " << pid << endl;
                }
                this_thread::sleep_for(chrono::milliseconds(100));
                elevator_positions[id] = dest;
            }

            {
                lock_guard<mutex> cout_lock(cout_mtx);
                cout << "Person " << pid << " exited Elevator " << id << " at floor " << dest << endl;
            }

            --occupancy;
        }

        passengers.clear();
    }

    {
        lock_guard<mutex> lock(cout_mtx);
        cout << "Elevator " << id << " has finished servicing all people." << endl;
        cout << "Elevator " << id << " serviced " << global_passengers_serviced[id] << " passengers." << endl;
    }
}

#endif // ELEVATOR_HPP
