#include <mpi.h>
#include <vector>
#include <fstream>
#include <iostream>
#include <string>
#include "my_broadcast.hpp"

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);

    int rank, np;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &np);

    std::vector<size_t> sizes;
    for (size_t s = 8; s <= (1u << 28); s <<= 1) {
        sizes.push_back(s);
    }

    const int WARM = 10;
    const int ITERS = 100;

    if (rank == 0) {
        std::ofstream out("bandwidth.csv");
        out << "np,size,impl,bandwidth\n";
        out.close();
    }
    MPI_Barrier(MPI_COMM_WORLD);

    for (size_t sz : sizes) {
        std::vector<char> buffer(sz);

        for (auto impl : {"my_broadcast", "MPI_Bcast"}) {
            for (int i = 0; i < WARM; ++i) {
                if (impl == std::string("my_broadcast"))
                    my_broadcast(buffer.data(), sz, 0, MPI_COMM_WORLD);
                else
                    MPI_Bcast(buffer.data(), sz, MPI_BYTE, 0, MPI_COMM_WORLD);
            }
            MPI_Barrier(MPI_COMM_WORLD);

            double t0 = MPI_Wtime();
            for (int i = 0; i < ITERS; ++i) {
                if (impl == std::string("my_broadcast"))
                    my_broadcast(buffer.data(), sz, 0, MPI_COMM_WORLD);
                else
                    MPI_Bcast(buffer.data(), sz, MPI_BYTE, 0, MPI_COMM_WORLD);
            }
            double t1 = MPI_Wtime();

            double avg_time = (t1 - t0) / ITERS;
            double bandwidth = sz / avg_time;

            if (rank == 0) {
                std::ofstream out("bandwidth.csv", std::ios::app);
                out << np << "," << sz << "," << impl << "," << std::scientific << bandwidth << "\n";
                out.close();
            }

            MPI_Barrier(MPI_COMM_WORLD);
        }
    }

    MPI_Finalize();
    return 0;
}
