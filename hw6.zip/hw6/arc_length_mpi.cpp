#include <mpi.h>
#include <cmath>
#include <iostream>

double f_prime(double x) {
    return 1.0 / x - x / 4.0;
}

double integrand(double x) {
    double fp = f_prime(x);
    return std::sqrt(1.0 + fp * fp);
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        if (argc == 1) {
            std::cerr << "Usage: mpirun -n <num_processes> ./arc_length_mpi <n>" << std::endl;
        }
        return 1;
    }

    int n = std::stoi(argv[1]);
    double a = 1.0, b = 6.0;
    double h = (b - a) / n;

    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int local_n = n / size;
    int start = rank * local_n;
    int end = (rank == size - 1) ? n : start + local_n;

    double local_sum = 0.0;
    for (int i = start; i < end; ++i) {
        double x = a + i * h;
        local_sum += integrand(x);
    }

    local_sum *= h;

    double global_sum = 0.0;
    MPI_Reduce(&local_sum, &global_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    if (rank == 0) {
        std::cout << "n=" << n << ", processes=" << size << ", arc length = " << global_sum << std::endl;
    }

    MPI_Finalize();
    return 0;
}
