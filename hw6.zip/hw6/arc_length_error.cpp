#include <iostream>
#include <vector>
#include <thread>
#include <cmath>
#include <mutex>
#include <chrono>
#include <fstream>

std::mutex mtx;

// f'(x) and integrand definition
double f_prime(double x) {
    return 1.0 / x - x / 4.0;
}

double integrand(double x) {
    double fp = f_prime(x);
    return std::sqrt(1.0 + fp * fp);
}

// Compute partial Riemann sum
void partial_integral(double a, double b, int start, int end, int n, double& result) {
    double h = (b - a) / n;
    double local_sum = 0.0;
    for (int i = start; i < end; ++i) {
        double x = a + i * h;
        local_sum += integrand(x);
    }
    local_sum *= h;

    std::lock_guard<std::mutex> lock(mtx);
    result += local_sum;
}

int main() {
    double a = 1.0, b = 6.0;
    int num_threads = 4;  // fixed for error study

    // exact value from symbolic integration in part (a)
    double exact = 35.0 / 8.0 + std::log(6.0);

    std::ofstream fout("arc_length_error.csv");
    fout << "n,log10_error\n";

    for (int n = 10; n <= 10000000; n *= 10) {
        double result = 0.0;
        std::vector<std::thread> threads;
        int chunk_size = n / num_threads;

        for (int i = 0; i < num_threads; ++i) {
            int start_idx = i * chunk_size;
            int end_idx = (i == num_threads - 1) ? n : (i + 1) * chunk_size;
            threads.emplace_back(partial_integral, a, b, start_idx, end_idx, n, std::ref(result));
        }

        for (auto& t : threads) t.join();

        double abs_error = std::abs(result - exact);
        double log_err = std::log10(abs_error);

        std::cout << "n = " << n << ", error = " << abs_error << ", log10(error) = " << log_err << "\n";
        fout << n << "," << log_err << "\n";
    }

    fout.close();
    return 0;
}
